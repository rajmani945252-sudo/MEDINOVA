import { useState, useEffect, useRef } from "react";

const UPCOMING = [
  { id: "VC001", patient: "Aarav Mehta", age: 34, time: "10:00 AM", date: "Today", reason: "Diabetes Follow-up", status: "waiting" },
  { id: "VC002", patient: "Priya Sharma", age: 28, time: "11:30 AM", date: "Today", reason: "Asthma Review", status: "scheduled" },
  { id: "VC003", patient: "Rajan Iyer", age: 52, time: "02:00 PM", date: "Today", reason: "Post-op checkup", status: "scheduled" },
  { id: "VC004", patient: "Meena Kapoor", age: 45, time: "09:00 AM", date: "Tomorrow", reason: "Hypertension", status: "scheduled" },
];

const PATIENT_RECORDS = {
  VC001: {
    bloodGroup: "B+", allergies: "Penicillin", conditions: ["Type 2 Diabetes", "Mild Hypertension"],
    medications: ["Metformin 500mg", "Amlodipine 5mg"],
    visits: [
      { date: "12 Mar 2025", note: "HbA1c improved to 7.1%. Continued current medication." },
      { date: "10 Jan 2025", note: "Blood sugar elevated. Increased Metformin dosage." },
      { date: "05 Nov 2024", note: "Initial diagnosis of Type 2 Diabetes." },
    ],
  },
  VC002: {
    bloodGroup: "O+", allergies: "Dust, Pollen", conditions: ["Asthma (Moderate)"],
    medications: ["Salbutamol Inhaler", "Fluticasone 100mcg"],
    visits: [
      { date: "20 Feb 2025", note: "Mild exacerbation. Added Fluticasone inhaler." },
      { date: "15 Dec 2024", note: "Routine review. No symptoms. Inhaler technique corrected." },
    ],
  },
  VC003: {
    bloodGroup: "A+", allergies: "None", conditions: ["Post Appendectomy"],
    medications: ["Amoxicillin 500mg (course)"],
    visits: [
      { date: "01 Apr 2025", note: "Appendectomy performed. Smooth recovery noted." },
    ],
  },
  VC004: {
    bloodGroup: "AB-", allergies: "Sulfa drugs", conditions: ["Hypertension Stage 1"],
    medications: ["Losartan 50mg", "Hydrochlorothiazide 12.5mg"],
    visits: [
      { date: "05 Mar 2025", note: "BP 148/92. Added Hydrochlorothiazide." },
      { date: "10 Jan 2025", note: "Diagnosed with Stage 1 Hypertension." },
    ],
  },
};

const C = {
  teal:       "#0d9488",
  tealDark:   "#0f766e",
  tealDeep:   "#134e4a",
  tealLight:  "#ccfbf1",
  tealXLight: "#f0fdf9",
  mint:       "#a7f3d0",
  mintDeep:   "#059669",
  bg:         "#f0fdf9",
  bgDeep:     "#e0faf3",
  white:      "#ffffff",
  border:     "#99f6e4",
  textMain:   "#134e4a",
  textSub:    "#4d7c72",
  textMuted:  "#7fb3aa",
};

function avatarColor(name) {
  const colors = [C.teal, C.mintDeep, "#0891b2", "#0369a1", "#047857", "#0284c7"];
  let hash = 0;
  for (let c of name) hash = c.charCodeAt(0) + ((hash << 5) - hash);
  return colors[Math.abs(hash) % colors.length];
}

// ── Records Modal ─────────────────────────────────────────────────────────────
function RecordsModal({ patient, onClose }) {
  const rec = PATIENT_RECORDS[patient.id];
  return (
    <div style={M.overlay} onClick={onClose}>
      <div style={M.modal} onClick={(e) => e.stopPropagation()}>
        <div style={M.modalHeader}>
          <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
            <div style={{ ...S.avatar, background: avatarColor(patient.patient), width: "48px", height: "48px", fontSize: "17px" }}>
              {patient.patient.split(" ").map((n) => n[0]).join("")}
            </div>
            <div>
              <div style={{ fontSize: "18px", fontWeight: "800", color: C.tealDeep }}>{patient.patient}</div>
              <div style={{ fontSize: "13px", color: C.textMuted }}>{patient.age} yrs · {rec.bloodGroup} · ID: {patient.id}</div>
            </div>
          </div>
          <button onClick={onClose} style={M.closeBtn}>✕</button>
        </div>

        <div style={M.grid2}>
          <div style={M.section}>
            <div style={M.sectionLabel}>Allergies</div>
            <div style={{ ...M.pill, background: "#fef2f2", color: "#991b1b", border: "1px solid #fca5a5" }}>{rec.allergies}</div>
          </div>
          <div style={M.section}>
            <div style={M.sectionLabel}>Blood Group</div>
            <div style={{ ...M.pill, background: C.tealXLight, color: C.tealDark, border: `1px solid ${C.tealLight}` }}>{rec.bloodGroup}</div>
          </div>
        </div>

        <div style={M.section}>
          <div style={M.sectionLabel}>Active Conditions</div>
          <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
            {rec.conditions.map((c) => (
              <div key={c} style={{ ...M.pill, background: "#fffbeb", color: "#92400e", border: "1px solid #fcd34d" }}>{c}</div>
            ))}
          </div>
        </div>

        <div style={M.section}>
          <div style={M.sectionLabel}>Current Medications</div>
          {rec.medications.map((m) => (
            <div key={m} style={M.medRow}>💊 {m}</div>
          ))}
        </div>

        <div style={M.section}>
          <div style={M.sectionLabel}>Visit History</div>
          {rec.visits.map((v, i) => (
            <div key={i} style={M.visitRow}>
              <div style={M.visitDate}>{v.date}</div>
              <div style={M.visitNote}>{v.note}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Prescription Modal ────────────────────────────────────────────────────────
function PrescriptionModal({ patient, onClose }) {
  const [lines, setLines] = useState([{ medicine: "", dosage: "", duration: "", instructions: "" }]);
  const [saved, setSaved] = useState(false);

  const updateLine = (i, field, val) => {
    const updated = [...lines];
    updated[i][field] = val;
    setLines(updated);
  };
  const addLine = () => setLines([...lines, { medicine: "", dosage: "", duration: "", instructions: "" }]);
  const removeLine = (i) => setLines(lines.filter((_, idx) => idx !== i));

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => { setSaved(false); onClose(); }, 1500);
  };

  return (
    <div style={M.overlay} onClick={onClose}>
      <div style={{ ...M.modal, maxWidth: "600px" }} onClick={(e) => e.stopPropagation()}>
        <div style={M.modalHeader}>
          <div>
            <div style={{ fontSize: "17px", fontWeight: "800", color: C.tealDeep }}>💊 Write Prescription</div>
            <div style={{ fontSize: "13px", color: C.textMuted }}>Patient: {patient.patient} · {new Date().toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}</div>
          </div>
          <button onClick={onClose} style={M.closeBtn}>✕</button>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: "10px", marginBottom: "16px" }}>
          {lines.map((line, i) => (
            <div key={i} style={M.rxRow}>
              <div style={M.rxNum}>{i + 1}</div>
              <div style={M.rxFields}>
                <input
                  placeholder="Medicine name"
                  value={line.medicine}
                  onChange={(e) => updateLine(i, "medicine", e.target.value)}
                  style={{ ...M.rxInput, flex: 2 }}
                />
                <input
                  placeholder="Dosage (e.g. 500mg)"
                  value={line.dosage}
                  onChange={(e) => updateLine(i, "dosage", e.target.value)}
                  style={{ ...M.rxInput, flex: 1 }}
                />
                <input
                  placeholder="Duration (e.g. 7 days)"
                  value={line.duration}
                  onChange={(e) => updateLine(i, "duration", e.target.value)}
                  style={{ ...M.rxInput, flex: 1 }}
                />
                <input
                  placeholder="Instructions (e.g. After meals)"
                  value={line.instructions}
                  onChange={(e) => updateLine(i, "instructions", e.target.value)}
                  style={{ ...M.rxInput, flex: 2 }}
                />
                {lines.length > 1 && (
                  <button onClick={() => removeLine(i)} style={M.rxRemove}>✕</button>
                )}
              </div>
            </div>
          ))}
        </div>

        <button onClick={addLine} style={M.addMedBtn}>+ Add Medicine</button>

        <div style={{ display: "flex", gap: "10px", marginTop: "16px" }}>
          <button onClick={onClose} style={{ ...M.actionBtn, background: C.white, color: C.tealDark, border: `1.5px solid ${C.teal}` }}>Cancel</button>
          <button onClick={handleSave} style={{ ...M.actionBtn, background: `linear-gradient(135deg, ${C.tealDark}, ${C.teal})`, color: "#fff", border: "none" }}>
            {saved ? "✓ Saved!" : "Save & Send Prescription"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Main Component ────────────────────────────────────────────────────────────
export default function VideoConsultation() {
  const [activeCall, setActiveCall] = useState(null);
  const [muted, setMuted] = useState(false);
  const [videoOff, setVideoOff] = useState(false);
  const [timer, setTimer] = useState(0);
  const [notes, setNotes] = useState("");
  const [notesSaved, setNotesSaved] = useState(false);
  const [chatMsg, setChatMsg] = useState("");
  const [chatLog, setChatLog] = useState([
    { from: "patient", text: "Hello Doctor, I've been feeling better since last visit.", time: "10:01 AM" },
  ]);
  const [activePanel, setActivePanel] = useState("notes");
  const [viewingRecords, setViewingRecords] = useState(null);
  const [showPrescription, setShowPrescription] = useState(false);
  const timerRef = useRef(null);

  useEffect(() => {
    if (activeCall) {
      timerRef.current = setInterval(() => setTimer((t) => t + 1), 1000);
    } else {
      clearInterval(timerRef.current);
      setTimer(0);
    }
    return () => clearInterval(timerRef.current);
  }, [activeCall]);

  const fmt = (s) => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;

  const sendChat = () => {
    if (!chatMsg.trim()) return;
    setChatLog([...chatLog, { from: "doctor", text: chatMsg, time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) }]);
    setChatMsg("");
  };

  const handleSaveNotes = () => {
    if (!notes.trim()) return;
    setNotesSaved(true);
    setTimeout(() => setNotesSaved(false), 2000);
  };

  const endCall = () => {
    setActiveCall(null);
    setMuted(false);
    setVideoOff(false);
    setNotes("");
    setNotesSaved(false);
    setShowPrescription(false);
    setChatLog([{ from: "patient", text: "Hello Doctor, I've been feeling better since last visit.", time: "10:01 AM" }]);
  };

  return (
    <div style={S.page}>
      {/* Records Modal */}
      {viewingRecords && (
        <RecordsModal patient={viewingRecords} onClose={() => setViewingRecords(null)} />
      )}

      {!activeCall ? (
        <div style={S.waitingRoom}>
          <div style={S.header}>
            <div>
              <div style={S.breadcrumb}>Doctor Dashboard / Consultations</div>
              <h1 style={S.title}>Video Consultations</h1>
              <p style={S.subtitle}>Manage and start your scheduled video calls</p>
            </div>
            <div style={S.statRow}>
              <div style={S.statPillGreen}>
                <span style={S.dot} />
                {UPCOMING.filter((c) => c.status === "waiting").length} Patient Waiting
              </div>
              <div style={S.statPillTeal}>{UPCOMING.length} Total Today</div>
            </div>
          </div>

          <div style={S.consultGrid}>
            {UPCOMING.map((c) => (
              <div key={c.id} style={{ ...S.consultCard, ...(c.status === "waiting" ? S.waitingCard : {}) }}>
                {c.status === "waiting" && <div style={S.waitingBanner}>🟢 Patient is waiting</div>}
                <div style={S.consultTop}>
                  <div style={{ ...S.avatar, background: avatarColor(c.patient) }}>
                    {c.patient.split(" ").map((n) => n[0]).join("")}
                  </div>
                  <div>
                    <div style={S.consultPatient}>{c.patient}</div>
                    <div style={S.consultSub}>{c.age} years old</div>
                  </div>
                </div>
                <div style={S.consultMeta}>
                  <div style={S.metaItem}>
                    <span style={S.metaLabel}>🕐 Time</span>
                    <span style={S.metaVal}>{c.date}, {c.time}</span>
                  </div>
                  <div style={S.metaItem}>
                    <span style={S.metaLabel}>📋 Reason</span>
                    <span style={S.metaVal}>{c.reason}</span>
                  </div>
                </div>
                <div style={S.consultActions}>
                  <button onClick={() => setViewingRecords(c)} style={S.prepBtn}>View Records</button>
                  <button
                    onClick={() => setActiveCall(c)}
                    style={{ ...S.joinBtn, ...(c.status === "waiting" ? S.joinBtnActive : {}) }}
                  >
                    {c.status === "waiting" ? "▶ Join Now" : "📅 Start Call"}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div style={S.callView}>
          {/* Prescription Modal inside call */}
          {showPrescription && (
            <PrescriptionModal patient={activeCall} onClose={() => setShowPrescription(false)} />
          )}

          <div style={S.videoSection}>
            <div style={S.mainVideo}>
              <div style={S.videoPlaceholder}>
                <div style={{ ...S.avatarXl, background: avatarColor(activeCall.patient) }}>
                  {activeCall.patient.split(" ").map((n) => n[0]).join("")}
                </div>
                <div style={S.videoPatientName}>{activeCall.patient}</div>
                <div style={S.videoStatus}>{videoOff ? "Camera Off" : "Video Connected"}</div>
              </div>

              <div style={S.selfVideo}>
                <div style={S.selfPlaceholder}>
                  {videoOff ? "📷" : "👨‍⚕️"}
                  <div style={S.selfLabel}>You</div>
                </div>
              </div>

              <div style={S.callTimer}>
                <span style={S.timerDot} />
                {fmt(timer)}
              </div>

              <div style={S.callInfo}>
                <span style={S.callInfoText}>{activeCall.patient} · {activeCall.reason}</span>
              </div>
            </div>

            <div style={S.controls}>
              <button onClick={() => setMuted(!muted)} style={{ ...S.ctrlBtn, ...(muted ? S.ctrlBtnActive : {}) }}>
                {muted ? "🔇" : "🎤"}<span style={S.ctrlLabel}>{muted ? "Unmute" : "Mute"}</span>
              </button>
              <button onClick={() => setVideoOff(!videoOff)} style={{ ...S.ctrlBtn, ...(videoOff ? S.ctrlBtnActive : {}) }}>
                {videoOff ? "📷" : "📹"}<span style={S.ctrlLabel}>{videoOff ? "Start Video" : "Stop Video"}</span>
              </button>
              <button style={S.ctrlBtn}>🖥️<span style={S.ctrlLabel}>Share Screen</span></button>
              <button style={S.ctrlBtn}>⏺️<span style={S.ctrlLabel}>Record</span></button>
              <button onClick={endCall} style={S.endBtn}>📵<span style={S.ctrlLabel}>End Call</span></button>
            </div>
          </div>

          <div style={S.sidePanel}>
            <div style={S.panelTabs}>
              {["notes", "chat", "info"].map((p) => (
                <button key={p} onClick={() => setActivePanel(p)}
                  style={{ ...S.panelTab, ...(activePanel === p ? S.panelTabActive : {}) }}>
                  {p === "notes" ? "📝 Notes" : p === "chat" ? "💬 Chat" : "👤 Patient"}
                </button>
              ))}
            </div>

            {activePanel === "notes" && (
              <div style={S.notesPanel}>
                <div style={S.panelTitle}>Consultation Notes</div>
                <textarea
                  value={notes}
                  onChange={(e) => { setNotes(e.target.value); setNotesSaved(false); }}
                  placeholder={"Type your consultation notes here…\n• Symptoms reported\n• Examination findings\n• Prescription plan"}
                  style={S.notesArea}
                />
                {notesSaved && (
                  <div style={S.savedBadge}>✓ Notes saved successfully</div>
                )}
                <div style={S.noteActions}>
                  <button onClick={() => setShowPrescription(true)} style={S.noteBtn}>💊 Write Prescription</button>
                  <button onClick={handleSaveNotes} style={S.noteBtn2}>
                    {notesSaved ? "✓ Saved!" : "📋 Save Notes"}
                  </button>
                </div>
              </div>
            )}

            {activePanel === "chat" && (
              <div style={S.chatPanel}>
                <div style={S.chatLog}>
                  {chatLog.map((m, i) => (
                    <div key={i} style={{ ...S.chatBubble, ...(m.from === "doctor" ? S.chatDoctor : S.chatPatient) }}>
                      <div style={S.chatText}>{m.text}</div>
                      <div style={S.chatTime}>{m.time}</div>
                    </div>
                  ))}
                </div>
                <div style={S.chatInput}>
                  <input
                    value={chatMsg}
                    onChange={(e) => setChatMsg(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && sendChat()}
                    placeholder="Type a message…"
                    style={S.chatField}
                  />
                  <button onClick={sendChat} style={S.sendBtn}>➤</button>
                </div>
              </div>
            )}

            {activePanel === "info" && (
              <div style={S.infoPanel}>
                <div style={{ ...S.avatarLg, background: avatarColor(activeCall.patient), margin: "0 auto 14px" }}>
                  {activeCall.patient.split(" ").map((n) => n[0]).join("")}
                </div>
                <div style={S.infoName}>{activeCall.patient}</div>
                <div style={S.infoAge}>{activeCall.age} years old</div>
                <div style={S.infoSection}>
                  <div style={S.infoSectionLabel}>Consultation Reason</div>
                  <div style={S.infoVal}>{activeCall.reason}</div>
                </div>
                <div style={S.infoSection}>
                  <div style={S.infoSectionLabel}>Appointment ID</div>
                  <div style={S.infoVal}>{activeCall.id}</div>
                </div>
                <button onClick={() => setViewingRecords(activeCall)} style={S.historyBtn}>View Full Medical History</button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ── Modal Styles ──────────────────────────────────────────────────────────────
const M = {
  overlay: {
    position: "fixed", inset: 0, background: "rgba(0,0,0,0.45)",
    display: "flex", alignItems: "center", justifyContent: "center",
    zIndex: 1000, padding: "20px",
  },
  modal: {
    background: "#fff", borderRadius: "20px",
    padding: "24px", width: "100%", maxWidth: "520px",
    maxHeight: "85vh", overflowY: "auto",
    boxShadow: "0 20px 60px rgba(0,0,0,0.25)",
  },
  modalHeader: {
    display: "flex", justifyContent: "space-between", alignItems: "flex-start",
    marginBottom: "20px",
  },
  closeBtn: {
    width: "32px", height: "32px", borderRadius: "50%",
    border: `1px solid ${C.tealLight}`, background: C.tealXLight,
    color: C.tealDark, cursor: "pointer", fontSize: "13px",
    display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
  },
  grid2: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px", marginBottom: "16px" },
  section: { marginBottom: "16px" },
  sectionLabel: {
    fontSize: "11px", fontWeight: "700", color: C.textMuted,
    textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: "8px",
  },
  pill: {
    display: "inline-block", padding: "4px 12px",
    borderRadius: "20px", fontSize: "13px", fontWeight: "600",
  },
  medRow: {
    padding: "8px 12px", borderRadius: "8px",
    background: C.tealXLight, color: C.tealDeep,
    fontSize: "13px", marginBottom: "6px",
    border: `1px solid ${C.tealLight}`,
  },
  visitRow: {
    padding: "10px 14px", borderRadius: "10px",
    background: "#fafafa", border: "1px solid #f0f0f0",
    marginBottom: "8px",
  },
  visitDate: { fontSize: "11px", color: C.teal, fontWeight: "700", marginBottom: "4px" },
  visitNote: { fontSize: "13px", color: C.tealDeep, lineHeight: "1.5" },

  // Prescription
  rxRow: { display: "flex", gap: "10px", alignItems: "flex-start" },
  rxNum: {
    width: "24px", height: "24px", borderRadius: "50%",
    background: C.teal, color: "#fff",
    display: "flex", alignItems: "center", justifyContent: "center",
    fontSize: "11px", fontWeight: "700", flexShrink: 0, marginTop: "8px",
  },
  rxFields: { flex: 1, display: "flex", flexWrap: "wrap", gap: "6px" },
  rxInput: {
    padding: "8px 12px", borderRadius: "8px",
    border: `1.5px solid ${C.border}`,
    fontSize: "13px", outline: "none",
    background: C.tealXLight, color: C.tealDeep,
    minWidth: "100px",
  },
  rxRemove: {
    padding: "6px 10px", border: "1px solid #fca5a5",
    background: "#fef2f2", color: "#dc2626",
    borderRadius: "8px", cursor: "pointer", fontSize: "11px",
  },
  addMedBtn: {
    padding: "9px 16px", borderRadius: "10px",
    border: `1.5px dashed ${C.teal}`, background: "transparent",
    color: C.tealDark, fontSize: "13px", fontWeight: "600",
    cursor: "pointer", width: "100%",
  },
  actionBtn: {
    flex: 1, padding: "11px", borderRadius: "10px",
    fontSize: "13px", fontWeight: "600", cursor: "pointer",
  },
};

// ── Page Styles ───────────────────────────────────────────────────────────────
const S = {
  page: {
    minHeight: "100vh",
    background: `linear-gradient(135deg, ${C.bg} 0%, ${C.bgDeep} 100%)`,
    fontFamily: "'DM Sans', 'Segoe UI', sans-serif",
  },
  waitingRoom: { padding: "32px" },
  header: {
    display: "flex", justifyContent: "space-between", alignItems: "flex-start",
    marginBottom: "28px", flexWrap: "wrap", gap: "16px",
  },
  breadcrumb: { fontSize: "12px", color: C.textSub, marginBottom: "6px" },
  title: { fontSize: "28px", fontWeight: "800", color: C.tealDeep, margin: 0 },
  subtitle: { fontSize: "14px", color: C.textSub, margin: "6px 0 0" },
  statRow: { display: "flex", gap: "12px", alignItems: "center" },
  statPillGreen: {
    background: "#dcfce7", border: "1px solid #86efac",
    color: "#166534", borderRadius: "20px", padding: "8px 16px",
    fontSize: "13px", fontWeight: "600",
    display: "flex", alignItems: "center", gap: "6px",
  },
  dot: { width: "8px", height: "8px", borderRadius: "50%", background: "#22c55e" },
  statPillTeal: {
    background: C.tealLight, color: C.tealDark,
    borderRadius: "20px", padding: "8px 16px",
    fontSize: "13px", fontWeight: "600",
  },
  consultGrid: {
    display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "20px",
  },
  consultCard: {
    background: C.white, borderRadius: "16px", padding: "20px",
    boxShadow: "0 2px 16px rgba(13,148,136,0.09)",
    border: `1px solid ${C.tealLight}`, transition: "all 0.2s",
  },
  waitingCard: { border: `2px solid ${C.teal}`, boxShadow: `0 4px 20px ${C.teal}28` },
  waitingBanner: {
    background: C.tealXLight, color: C.tealDark,
    borderRadius: "8px", padding: "6px 12px",
    fontSize: "12px", fontWeight: "600", marginBottom: "14px",
    border: `1px solid ${C.tealLight}`,
  },
  consultTop: { display: "flex", gap: "12px", alignItems: "center", marginBottom: "14px" },
  avatar: {
    width: "44px", height: "44px", borderRadius: "50%",
    display: "flex", alignItems: "center", justifyContent: "center",
    color: "#fff", fontWeight: "700", fontSize: "15px", flexShrink: 0,
  },
  consultPatient: { fontSize: "16px", fontWeight: "700", color: C.tealDeep },
  consultSub: { fontSize: "12px", color: C.textMuted, marginTop: "2px" },
  consultMeta: { marginBottom: "16px" },
  metaItem: { display: "flex", gap: "8px", marginBottom: "6px" },
  metaLabel: { fontSize: "12px", color: C.textMuted, minWidth: "80px" },
  metaVal: { fontSize: "13px", color: C.tealDeep, fontWeight: "500" },
  consultActions: { display: "flex", gap: "10px" },
  prepBtn: {
    flex: 1, padding: "9px", borderRadius: "10px",
    border: `1.5px solid ${C.teal}`, background: C.white,
    color: C.tealDark, fontSize: "13px", fontWeight: "600", cursor: "pointer",
  },
  joinBtn: {
    flex: 1, padding: "9px", borderRadius: "10px", border: "none",
    background: `linear-gradient(135deg, ${C.tealDark}, #555)`,
    color: "#fff", fontSize: "13px", fontWeight: "600", cursor: "pointer",
  },
  joinBtnActive: {
    background: `linear-gradient(135deg, ${C.tealDark}, ${C.teal})`,
    boxShadow: `0 4px 14px ${C.teal}55`,
  },
  callView: { display: "flex", height: "100vh" },
  videoSection: { flex: 1, display: "flex", flexDirection: "column", background: "#0a1628" },
  mainVideo: {
    flex: 1, position: "relative",
    display: "flex", alignItems: "center", justifyContent: "center",
    background: "radial-gradient(ellipse at center, #0d2240 0%, #060e1c 100%)",
  },
  videoPlaceholder: { display: "flex", flexDirection: "column", alignItems: "center", gap: "12px" },
  avatarXl: {
    width: "100px", height: "100px", borderRadius: "50%",
    display: "flex", alignItems: "center", justifyContent: "center",
    color: "#fff", fontWeight: "800", fontSize: "32px",
    boxShadow: `0 0 40px ${C.teal}55`,
  },
  videoPatientName: { fontSize: "22px", fontWeight: "700", color: "#fff" },
  videoStatus: {
    fontSize: "13px", color: C.mint,
    background: "rgba(255,255,255,0.08)", padding: "4px 14px", borderRadius: "20px",
  },
  selfVideo: {
    position: "absolute", bottom: "16px", right: "16px",
    width: "140px", height: "90px",
    background: "#1a2a40", borderRadius: "10px",
    border: `2px solid ${C.teal}55`,
    display: "flex", alignItems: "center", justifyContent: "center",
  },
  selfPlaceholder: { display: "flex", flexDirection: "column", alignItems: "center", color: C.mint, fontSize: "28px" },
  selfLabel: { fontSize: "10px", color: C.mint, marginTop: "4px" },
  callTimer: {
    position: "absolute", top: "16px", left: "50%", transform: "translateX(-50%)",
    background: "rgba(0,0,0,0.5)", color: "#fff",
    borderRadius: "20px", padding: "6px 16px",
    fontSize: "15px", fontWeight: "700",
    display: "flex", alignItems: "center", gap: "8px",
    backdropFilter: "blur(8px)",
  },
  timerDot: { width: "8px", height: "8px", borderRadius: "50%", background: "#ff4444" },
  callInfo: {
    position: "absolute", bottom: "16px", left: "16px",
    background: "rgba(0,0,0,0.5)", borderRadius: "10px",
    padding: "8px 14px", backdropFilter: "blur(8px)",
  },
  callInfoText: { color: C.mint, fontSize: "13px" },
  controls: {
    background: C.tealDeep, padding: "16px",
    display: "flex", justifyContent: "center", gap: "16px", alignItems: "center",
  },
  ctrlBtn: {
    width: "64px", height: "64px", borderRadius: "50%", border: "none",
    background: "rgba(255,255,255,0.10)",
    color: "#fff", fontSize: "20px", cursor: "pointer",
    display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
    gap: "3px", transition: "all 0.2s",
  },
  ctrlBtnActive: { background: "rgba(255,80,80,0.25)", border: "1px solid rgba(255,80,80,0.4)" },
  ctrlLabel: { fontSize: "9px", color: C.mint },
  endBtn: {
    width: "64px", height: "64px", borderRadius: "50%", border: "none",
    background: "linear-gradient(135deg, #ff3333, #cc0000)",
    color: "#fff", fontSize: "20px", cursor: "pointer",
    display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
    gap: "3px", boxShadow: "0 0 16px rgba(255,50,50,0.4)",
  },
  sidePanel: {
    width: "320px", background: C.white, display: "flex", flexDirection: "column",
    borderLeft: `1px solid ${C.tealLight}`,
  },
  panelTabs: { display: "flex", borderBottom: `1px solid ${C.tealLight}` },
  panelTab: {
    flex: 1, padding: "13px 8px", border: "none", background: "transparent",
    fontSize: "12px", fontWeight: "600", cursor: "pointer",
    color: C.textMuted, borderBottom: "2px solid transparent",
  },
  panelTabActive: { color: C.tealDark, borderBottom: `2px solid ${C.teal}`, background: C.tealXLight },
  notesPanel: { padding: "16px", display: "flex", flexDirection: "column", flex: 1, gap: "12px" },
  panelTitle: { fontSize: "14px", fontWeight: "700", color: C.tealDeep },
  notesArea: {
    flex: 1, minHeight: "260px", padding: "12px", borderRadius: "10px",
    border: `1.5px solid ${C.border}`,
    fontSize: "13px", resize: "none", outline: "none",
    lineHeight: "1.6", fontFamily: "inherit",
    color: C.tealDeep, background: C.tealXLight,
  },
  savedBadge: {
    background: "#dcfce7", color: "#166534",
    border: "1px solid #86efac", borderRadius: "8px",
    padding: "8px 12px", fontSize: "12px", fontWeight: "600", textAlign: "center",
  },
  noteActions: { display: "flex", flexDirection: "column", gap: "8px" },
  noteBtn: {
    padding: "10px", borderRadius: "10px",
    border: `1.5px solid ${C.teal}`, background: C.white,
    color: C.tealDark, fontSize: "13px", fontWeight: "600", cursor: "pointer",
  },
  noteBtn2: {
    padding: "10px", borderRadius: "10px", border: "none",
    background: `linear-gradient(135deg, ${C.tealDark}, ${C.teal})`,
    color: "#fff", fontSize: "13px", fontWeight: "600", cursor: "pointer",
  },
  chatPanel: { display: "flex", flexDirection: "column", flex: 1 },
  chatLog: {
    flex: 1, padding: "16px", overflowY: "auto",
    display: "flex", flexDirection: "column", gap: "10px", minHeight: "300px",
  },
  chatBubble: { maxWidth: "80%", borderRadius: "12px", padding: "10px 14px" },
  chatDoctor: {
    background: `linear-gradient(135deg, ${C.tealDark}, ${C.teal})`,
    color: "#fff", alignSelf: "flex-end", borderBottomRightRadius: "4px",
  },
  chatPatient: { background: C.tealXLight, color: C.tealDeep, alignSelf: "flex-start", borderBottomLeftRadius: "4px" },
  chatText: { fontSize: "13px", lineHeight: "1.5" },
  chatTime: { fontSize: "10px", opacity: 0.6, marginTop: "4px", textAlign: "right" },
  chatInput: {
    display: "flex", gap: "8px", padding: "12px 16px",
    borderTop: `1px solid ${C.tealLight}`,
  },
  chatField: {
    flex: 1, padding: "9px 14px", borderRadius: "20px",
    border: `1.5px solid ${C.border}`,
    fontSize: "13px", outline: "none",
    background: C.tealXLight, fontFamily: "inherit", color: C.tealDeep,
  },
  sendBtn: {
    width: "38px", height: "38px", borderRadius: "50%", border: "none",
    background: `linear-gradient(135deg, ${C.tealDark}, ${C.teal})`,
    color: "#fff", fontSize: "14px", cursor: "pointer", flexShrink: 0,
  },
  infoPanel: { padding: "24px 20px", display: "flex", flexDirection: "column", alignItems: "center" },
  avatarLg: {
    width: "64px", height: "64px", borderRadius: "50%",
    display: "flex", alignItems: "center", justifyContent: "center",
    color: "#fff", fontWeight: "800", fontSize: "20px",
  },
  infoName: { fontSize: "18px", fontWeight: "700", color: C.tealDeep, marginBottom: "4px" },
  infoAge: { fontSize: "13px", color: C.textMuted, marginBottom: "20px" },
  infoSection: {
    width: "100%", marginBottom: "14px", background: C.tealXLight,
    borderRadius: "10px", padding: "12px 14px", border: `1px solid ${C.tealLight}`,
  },
  infoSectionLabel: {
    fontSize: "11px", color: C.textMuted, fontWeight: "700",
    textTransform: "uppercase", marginBottom: "4px", letterSpacing: "0.05em",
  },
  infoVal: { fontSize: "14px", color: C.tealDeep, fontWeight: "600" },
  historyBtn: {
    width: "100%", marginTop: "8px", padding: "11px",
    borderRadius: "10px", border: `1.5px solid ${C.teal}`,
    background: C.white, color: C.tealDark,
    fontSize: "13px", fontWeight: "600", cursor: "pointer",
  },
};