import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios'

function AdminAppointments() {
  const [appointments, setAppointments] = useState([])
  const [loading,      setLoading]      = useState(true)
  const [filter,       setFilter]       = useState('all')
  const token = localStorage.getItem('token')

  useEffect(() => {
    axios.get('http://localhost:5000/api/admin/appointments', {
      headers: { Authorization: `Bearer ${token}` }
    }).then(res => { setAppointments(res.data); setLoading(false) })
      .catch(console.log)
  }, [])

  const filters  = ['all','pending','confirmed','completed','rejected']
  const filtered = filter === 'all' ? appointments : appointments.filter(a => a.status === filter)

  return (
    <div className="page">
      <div className="page-content">

        <div className="fade-up" style={{ marginBottom:'28px' }}>
          <Link to="/admin/dashboard" style={{ color:'var(--color-text-muted)', fontSize:'13px', textDecoration:'none', display:'inline-flex', alignItems:'center', gap:'4px', marginBottom:'12px' }}>
            ← Back to Dashboard
          </Link>
          <h1 style={{ fontFamily:'var(--font-heading)', fontSize:'32px', color:'var(--color-primary)' }}>All Appointments</h1>
          <p style={{ color:'var(--color-text-muted)', fontSize:'14px', marginTop:'4px' }}>{appointments.length} total appointments</p>
        </div>

        <div className="fade-up-1" style={{ display:'flex', gap:'8px', flexWrap:'wrap', marginBottom:'24px' }}>
          {filters.map(f => (
            <button key={f} onClick={() => setFilter(f)} style={{
              padding:'8px 18px', borderRadius:'20px', fontFamily:'var(--font-main)',
              border:`1.5px solid ${filter===f ? 'var(--color-primary)' : 'var(--color-border)'}`,
              background: filter===f ? 'var(--color-primary)' : 'transparent',
              color: filter===f ? 'white' : 'var(--color-text-muted)',
              fontSize:'13px', fontWeight:'600', cursor:'pointer', transition:'var(--transition)', textTransform:'capitalize'
            }}>
              {f==='all' ? `All (${appointments.length})` : `${f} (${appointments.filter(a=>a.status===f).length})`}
            </button>
          ))}
        </div>

        {loading && <p style={{ color:'var(--color-text-muted)', padding:'40px 0' }}>Loading...</p>}

        <div className="fade-up-2" style={{ display:'flex', flexDirection:'column', gap:'12px' }}>
          {filtered.map(apt => (
            <div key={apt.id} style={{ background:'var(--color-surface)', border:'1px solid var(--color-border)', borderRadius:'var(--radius-lg)', padding:'18px 22px', display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:'12px', boxShadow:'var(--shadow-sm)' }}>
              <div style={{ display:'flex', alignItems:'center', gap:'14px' }}>
                <div style={{ width:'44px', height:'44px', background:'var(--color-primary-ghost)', borderRadius:'12px', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'18px' }}>📅</div>
                <div>
                  <div style={{ fontWeight:'700', fontSize:'15px', color:'var(--color-text-primary)' }}>
                    {apt.patient_name} → Dr. {apt.doctor_name}
                  </div>
                  <div style={{ color:'var(--color-text-muted)', fontSize:'12px', marginTop:'3px', display:'flex', gap:'12px', flexWrap:'wrap' }}>
                    <span>📅 {apt.date}</span>
                    <span>🕐 {apt.time_slot}</span>
                    <span>ID: #{apt.id}</span>
                  </div>
                </div>
              </div>
              <span className={`badge badge-${apt.status}`}>{apt.status}</span>
            </div>
          ))}
        </div>

        {!loading && filtered.length === 0 && (
          <div style={{ textAlign:'center', padding:'60px', color:'var(--color-text-muted)' }}>No appointments found</div>
        )}

      </div>
    </div>
  )
}

export default AdminAppointments