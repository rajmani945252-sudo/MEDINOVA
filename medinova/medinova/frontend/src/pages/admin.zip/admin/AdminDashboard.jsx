import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios'

function AdminDashboard() {
  const token = localStorage.getItem('token')
  const [stats, setStats] = useState({})
  const h = { headers: { Authorization: `Bearer ${token}` } }

  useEffect(() => {
    axios.get('http://localhost:5000/api/admin/stats', h)
      .then(res => setStats(res.data)).catch(console.log)
  }, [])

  const statCards = [
    { label:'Patients',      value: stats.patients,      icon:'🤒', color:'var(--color-primary)', bg:'var(--color-primary-ghost)' },
    { label:'Doctors',       value: stats.doctors,       icon:'🩺', color:'#1565C0',             bg:'#E3F2FD' },
    { label:'Stores',        value: stats.stores,        icon:'🏪', color:'#2E7D32',             bg:'#E8F5E9' },
    { label:'MRs',           value: stats.mrs,           icon:'💼', color:'#6A1B9A',             bg:'#F3E5F5' },
    { label:'Appointments',  value: stats.appointments,  icon:'📅', color:'#E65100',             bg:'#FFF3E0' },
    { label:'Prescriptions', value: stats.prescriptions, icon:'📋', color:'#00695C',             bg:'#E0F2F1' },
    { label:'Medicines',     value: stats.medicines,     icon:'💊', color:'#C62828',             bg:'#FFEBEE' },
  ]

  return (
    <div className="page">
      <div className="page-content">

        <div className="fade-up" style={{ marginBottom:'32px' }}>
          <p style={{ color:'var(--color-text-muted)', fontSize:'14px', marginBottom:'4px' }}>Admin Panel 🛡️</p>
          <h1 style={{ fontFamily:'var(--font-heading)', fontSize:'32px', color:'var(--color-primary)' }}>
            System Overview
          </h1>
          <p style={{ color:'var(--color-text-muted)', fontSize:'14px', marginTop:'6px' }}>
            Complete control of Medinova platform
          </p>
        </div>

        <div className="fade-up-1" style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(160px,1fr))', gap:'14px', marginBottom:'36px' }}>
          {statCards.map(s => (
            <div key={s.label} style={{ background:'var(--color-surface)', border:'1px solid var(--color-border)', borderRadius:'var(--radius-lg)', padding:'20px', boxShadow:'var(--shadow-sm)', transition:'var(--transition)' }}
              onMouseEnter={e => e.currentTarget.style.boxShadow='var(--shadow-hover)'}
              onMouseLeave={e => e.currentTarget.style.boxShadow='var(--shadow-sm)'}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'10px' }}>
                <span style={{ fontSize:'22px' }}>{s.icon}</span>
                <div style={{ background:s.bg, color:s.color, fontSize:'10px', fontWeight:'700', padding:'2px 8px', borderRadius:'20px', textTransform:'uppercase' }}>{s.label}</div>
              </div>
              <div style={{ fontSize:'28px', fontWeight:'800', color:s.color }}>{s.value ?? '...'}</div>
            </div>
          ))}
        </div>

        <div className="fade-up-2">
          <h2 style={{ fontFamily:'var(--font-heading)', fontSize:'22px', color:'var(--color-text-primary)', marginBottom:'16px' }}>Admin Actions</h2>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(220px,1fr))', gap:'16px' }}>
            {[
              { to:'/admin/users',        icon:'👥', title:'Manage Users',       desc:'View, verify and remove users',        color:'var(--color-primary)' },
              { to:'/admin/appointments', icon:'📅', title:'All Appointments',   desc:'Monitor all system appointments',      color:'#1565C0' },
            ].map(item => (
              <Link key={item.to} to={item.to} style={{ textDecoration:'none' }}>
                <div style={{ background:'var(--color-surface)', border:'1px solid var(--color-border)', borderRadius:'var(--radius-lg)', padding:'24px', boxShadow:'var(--shadow-sm)', transition:'var(--transition)' }}
                  onMouseEnter={e => { e.currentTarget.style.boxShadow='var(--shadow-hover)'; e.currentTarget.style.transform='translateY(-2px)'; }}
                  onMouseLeave={e => { e.currentTarget.style.boxShadow='var(--shadow-sm)'; e.currentTarget.style.transform='translateY(0)'; }}>
                  <div style={{ fontSize:'32px', marginBottom:'14px' }}>{item.icon}</div>
                  <div style={{ fontSize:'16px', fontWeight:'700', color:item.color, marginBottom:'6px' }}>{item.title}</div>
                  <div style={{ fontSize:'13px', color:'var(--color-text-muted)' }}>{item.desc}</div>
                  <div style={{ marginTop:'14px', color:item.color, fontSize:'13px', fontWeight:'700' }}>Manage →</div>
                </div>
              </Link>
            ))}
          </div>
        </div>

      </div>
    </div>
  )
}

export default AdminDashboard