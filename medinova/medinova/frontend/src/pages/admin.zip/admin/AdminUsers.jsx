import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios'

function AdminUsers() {
  const [users,   setUsers]   = useState([])
  const [loading, setLoading] = useState(true)
  const [filter,  setFilter]  = useState('all')
  const [search,  setSearch]  = useState('')
  const token = localStorage.getItem('token')
  const h     = { headers: { Authorization: `Bearer ${token}` } }

  const fetchUsers = () => {
    axios.get('http://localhost:5000/api/admin/users', h)
      .then(res => { setUsers(res.data); setLoading(false) })
      .catch(console.log)
  }

  useEffect(() => { fetchUsers() }, [])

  const handleDelete = async (id, name) => {
    if (!window.confirm(`Delete user ${name}? This cannot be undone.`)) return
    try {
      await axios.delete(`http://localhost:5000/api/admin/users/${id}`, h)
      fetchUsers()
    } catch (err) { console.log(err) }
  }

  const handleVerify = async (id) => {
    try {
      await axios.put(`http://localhost:5000/api/admin/users/${id}/verify`, {}, h)
      fetchUsers()
    } catch (err) { console.log(err) }
  }

  const roles   = ['all','patient','doctor','store','mr','admin']
  const filtered = users
    .filter(u => filter === 'all' || u.role === filter)
    .filter(u => u.name.toLowerCase().includes(search.toLowerCase()) ||
                 u.email.toLowerCase().includes(search.toLowerCase()))

  const roleColor = (role) => {
    const map = {
      patient: { bg:'var(--color-primary-ghost)', color:'var(--color-primary)' },
      doctor:  { bg:'#E3F2FD', color:'#1565C0' },
      admin:   { bg:'#FCE4EC', color:'#C62828' },
      store:   { bg:'#E8F5E9', color:'#2E7D32' },
      mr:      { bg:'#F3E5F5', color:'#6A1B9A' },
    }
    return map[role] || { bg:'#F5F5F5', color:'#333' }
  }

  return (
    <div className="page">
      <div className="page-content">

        <div className="fade-up" style={{ marginBottom:'28px' }}>
          <Link to="/admin/dashboard" style={{ color:'var(--color-text-muted)', fontSize:'13px', textDecoration:'none', display:'inline-flex', alignItems:'center', gap:'4px', marginBottom:'12px' }}>
            ← Back to Dashboard
          </Link>
          <h1 style={{ fontFamily:'var(--font-heading)', fontSize:'32px', color:'var(--color-primary)' }}>Manage Users</h1>
          <p style={{ color:'var(--color-text-muted)', fontSize:'14px', marginTop:'4px' }}>{users.length} total users</p>
        </div>

        <div className="fade-up-1" style={{ display:'flex', gap:'12px', flexWrap:'wrap', marginBottom:'20px', alignItems:'center' }}>
          <div style={{ position:'relative', flex:1, minWidth:'200px' }}>
            <span style={{ position:'absolute', left:'14px', top:'50%', transform:'translateY(-50%)', fontSize:'14px' }}>🔍</span>
            <input className="input" placeholder="Search by name or email..."
              value={search} onChange={e => setSearch(e.target.value)}
              style={{ paddingLeft:'40px' }} />
          </div>
          <div style={{ display:'flex', gap:'8px', flexWrap:'wrap' }}>
            {roles.map(r => (
              <button key={r} onClick={() => setFilter(r)} style={{
                padding:'8px 16px', borderRadius:'20px', fontFamily:'var(--font-main)',
                border:`1.5px solid ${filter===r ? 'var(--color-primary)' : 'var(--color-border)'}`,
                background: filter===r ? 'var(--color-primary)' : 'transparent',
                color: filter===r ? 'white' : 'var(--color-text-muted)',
                fontSize:'12px', fontWeight:'600', cursor:'pointer', transition:'var(--transition)', textTransform:'capitalize'
              }}>
                {r === 'all' ? `All (${users.length})` : `${r} (${users.filter(u=>u.role===r).length})`}
              </button>
            ))}
          </div>
        </div>

        {loading && <p style={{ color:'var(--color-text-muted)', padding:'40px 0' }}>Loading users...</p>}

        <div className="fade-up-2" style={{ display:'flex', flexDirection:'column', gap:'12px' }}>
          {filtered.map(u => {
            const rc = roleColor(u.role)
            return (
              <div key={u.id} style={{ background:'var(--color-surface)', border:'1px solid var(--color-border)', borderRadius:'var(--radius-lg)', padding:'18px 22px', display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:'12px', boxShadow:'var(--shadow-sm)' }}>
                <div style={{ display:'flex', alignItems:'center', gap:'14px' }}>
                  <div style={{ width:'44px', height:'44px', background:rc.bg, borderRadius:'12px', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'18px', fontWeight:'700', color:rc.color, flexShrink:0 }}>
                    {u.name.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <div style={{ fontWeight:'700', fontSize:'15px', color:'var(--color-text-primary)', display:'flex', alignItems:'center', gap:'8px' }}>
                      {u.name}
                      {u.is_verified ? (
                        <span style={{ background:'#E8F5E9', color:'#2E7D32', fontSize:'10px', padding:'2px 8px', borderRadius:'10px', fontWeight:'700' }}>✓ Verified</span>
                      ) : (
                        <span style={{ background:'#FFF3E0', color:'#E65100', fontSize:'10px', padding:'2px 8px', borderRadius:'10px', fontWeight:'700' }}>Unverified</span>
                      )}
                    </div>
                    <div style={{ color:'var(--color-text-muted)', fontSize:'12px', marginTop:'3px' }}>
                      {u.email} {u.phone && `· ${u.phone}`}
                    </div>
                    <div style={{ fontSize:'11px', color:'var(--color-text-muted)', marginTop:'2px' }}>
                      Joined: {new Date(u.created_at).toLocaleDateString()}
                    </div>
                  </div>
                </div>
                <div style={{ display:'flex', alignItems:'center', gap:'10px', flexWrap:'wrap' }}>
                  <span style={{ background:rc.bg, color:rc.color, padding:'4px 14px', borderRadius:'20px', fontSize:'12px', fontWeight:'700', textTransform:'capitalize' }}>
                    {u.role}
                  </span>
                  {!u.is_verified && (
                    <button className="btn-outline" onClick={() => handleVerify(u.id)} style={{ padding:'6px 14px', fontSize:'12px' }}>
                      Verify
                    </button>
                  )}
                  {u.role !== 'admin' && (
                    <button className="btn-danger" onClick={() => handleDelete(u.id, u.name)} style={{ padding:'6px 14px', fontSize:'12px' }}>
                      Delete
                    </button>
                  )}
                </div>
              </div>
            )
          })}
        </div>

        {!loading && filtered.length === 0 && (
          <div style={{ textAlign:'center', padding:'60px', color:'var(--color-text-muted)' }}>
            No users found matching your search
          </div>
        )}

      </div>
    </div>
  )
}

export default AdminUsers